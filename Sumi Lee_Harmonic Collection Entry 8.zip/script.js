document.addEventListener("DOMContentLoaded", () => {
    const sendMessageButton = document.getElementById("sendMessage");
    const messageInput = document.getElementById("messageInput");
    const conversation = document.querySelector(".conversation");

    // Lyrics to the song "Here I Am to Worship"
    const lyrics = [
        "Light of the world You stepped down into darkness Opened my eyes, let me see Beauty that made this heart adore You Hope of a life spent with You",
        "Here I am to worship Here I am to bow down Here I am to say that You're my God",
        "You're altogether lovely Altogether worthy Altogether wonderful to me",
        "King of all days Oh, so highly exalted Glorious in heaven above Humbly You came to the earth You created All for love's sake became poor",
        "Here I am to worship Here I am to bow down Here I am to say that You're my God",
        "You're altogether lovely Altogether worthy Altogether wonderful to me",
        "Well, I'll never know how much it cost To see my sin upon that cross",
        // Add more lyrics here
    ];

    let currentIndex = 0;

    sendMessageButton.addEventListener("click", () => {
        const userMessage = messageInput.value;

        if (userMessage) {
            // Add user's custom message
            const userMessageBubble = document.createElement("div");
            userMessageBubble.textContent = userMessage;
            userMessageBubble.classList.add("message", "sent");
            conversation.appendChild(userMessageBubble);
            conversation.scrollTop = conversation.scrollHeight;
            messageInput.value = ""; // Clear the input box

            if (currentIndex < lyrics.length) {
                // Add next lyric
                const lyric = lyrics[currentIndex];
                const lyricMessageBubble = document.createElement("div");
                lyricMessageBubble.textContent = lyric;
                lyricMessageBubble.classList.add("message", "received");
                conversation.appendChild(lyricMessageBubble);
                conversation.scrollTop = conversation.scrollHeight;
                currentIndex++;
            }
        } else if (currentIndex < lyrics.length) {
            // Add next lyric if no user message is entered
            const lyric = lyrics[currentIndex];
            const lyricMessageBubble = document.createElement("div");
            lyricMessageBubble.textContent = lyric;
            lyricMessageBubble.classList.add("message", "received");
            conversation.appendChild(lyricMessageBubble);
            conversation.scrollTop = conversation.scrollHeight;
            currentIndex++;
        }
    });
});

document.addEventListener("DOMContentLoaded", () => {
    const audioPlayer = document.getElementById("audioPlayer");
    const audioResumeButton = document.getElementById("audioResumeButton");

    function updateAudioButton() {
        if (audioPlayer.paused) {
            audioResumeButton.textContent = "▶"; // Change text to "Resume"
        } else {
            audioResumeButton.textContent = "▐▐ "; // Change text to "Pause"
        }
    }

    audioResumeButton.addEventListener("click", () => {
        if (audioPlayer.paused) {
            audioPlayer.play();
        } else {
            audioPlayer.pause();
        }

        // Update the button text and icon
        updateAudioButton();
    });

    // Add an event listener for the audio player to update the button when audio state changes
    audioPlayer.addEventListener("play", () => {
        updateAudioButton();
    });

    audioPlayer.addEventListener("pause", () => {
        updateAudioButton();
    });
});