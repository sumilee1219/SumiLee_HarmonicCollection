document.addEventListener('DOMContentLoaded', function () {
    var elements = document.getElementById('typewriter');
    var nextButton = document.getElementById('nextButton');
    var lyrics = [
    "In the darkness we were waiting\nWithout hope without light\nTill from heaven You came running\nThere was mercy in Your eyes",
    "To fulfil the law and prophets\nTo a virgin came the Word\nFrom a throne of endless glory\nTo a cradle in the dirt",
    "Praise the Father\nPraise the Son\nPraise the Spirit three in one\nGod of glory\nMajesty\nPraise forever to the King of Kings",
    "To reveal the kingdom coming\nAnd to reconcile the lost\nTo redeem the whole creation\nYou did not despise the cross",
    "For even in Your suffering\nYou saw to the other side\nKnowing this was our salvation\nJesus for our sake You died",
    "And the morning that You rose\nAll of heaven held its breath\nTill that stone was moved for good\nFor the Lamb had conquered death",
    "And the dead rose from their tombs\nAnd the angels stood in awe\nFor the souls of all who’d come\nTo the Father are restored",
    "And the Church of Christ was born\nThen the Spirit lit the flame\nNow this gospel truth of old\nShall not kneel shall not faint",
    "By His blood and in His Name\nIn His freedom I am free\nFor the love of Jesus Christ\nWho has resurrected me"

    ];
    var currentSlide = 0;
    var speed = 80;

    function type() {
        if (lyrics[currentSlide].length > 0) {
            elements.innerHTML += lyrics[currentSlide].charAt(0);
            lyrics[currentSlide] = lyrics[currentSlide].substring(1);
            setTimeout(type, speed);
        } else {

            if (currentSlide === lyrics.length - 1) {
                nextButton.disabled = true;
  
            }
        }
    }

function nextSlide() {
        currentSlide = (currentSlide + 1) % lyrics.length;
        elements.innerHTML = '';
        nextButton.disabled = false;
        type();
    }


    nextButton.addEventListener('click', nextSlide);

    type();


});

document.addEventListener("DOMContentLoaded", () => {
    const audioPlayer = document.getElementById("audioPlayer");
    const audioResumeButton = document.getElementById("audioResumeButton");

    function updateAudioButton() {
        if (audioPlayer.paused) {
            audioResumeButton.textContent = "▶️"; 
        } else {
            audioResumeButton.textContent = "⏸ "; 
        }
    }

    audioResumeButton.addEventListener("click", () => {
        if (audioPlayer.paused) {
            audioPlayer.play();
        } else {
            audioPlayer.pause();
        }


        updateAudioButton();
    });

   
    audioPlayer.addEventListener("play", () => {
        updateAudioButton();
    });

    audioPlayer.addEventListener("pause", () => {
        updateAudioButton();
    });
});

