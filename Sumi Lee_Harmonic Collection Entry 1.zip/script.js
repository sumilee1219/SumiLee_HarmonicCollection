document.addEventListener("scroll", function() {
    const scrollTop = window.scrollY;
    const lightBeam = document.querySelector(".light-beam");
    
    // Adjust the radial gradient size based on scroll position
    const gradientSize = Math.min(scrollTop / 5, 100);
    lightBeam.style.backgroundSize = `${gradientSize}vmax ${gradientSize}vmax`;
});
