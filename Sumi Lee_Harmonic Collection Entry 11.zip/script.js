document.addEventListener('DOMContentLoaded', function () {
    const character = document.getElementById('character');

    document.addEventListener('keydown', function (event) {
        moveCharacter(event);
    });
});

function moveCharacter(event) {
    const character = document.getElementById('character');
    const characterSpeed = 10;

    switch (event.key) {
        case 'ArrowUp':
            character.style.top = Math.max(0, character.offsetTop - characterSpeed) + 'px';
            break;
        case 'ArrowDown':
            character.style.top = Math.min(window.innerHeight - character.clientHeight, character.offsetTop + characterSpeed) + 'px';
            break;
        case 'ArrowLeft':
            character.style.left = Math.max(0, character.offsetLeft - characterSpeed) + 'px';
            break;
        case 'ArrowRight':
            character.style.left = Math.min(window.innerWidth - character.clientWidth, character.offsetLeft + characterSpeed) + 'px';
            break;
    }
}
