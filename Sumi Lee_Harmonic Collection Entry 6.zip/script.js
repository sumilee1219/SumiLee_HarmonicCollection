const audio = document.getElementById("audio");
const playButton = document.querySelector('audio::-webkit-media-controls-play-button');

function playAudio() {
    if (audio.paused) {
        audio.play();
    } else {
        audio.pause();
    }
}

playButton.style.display = 'none';

