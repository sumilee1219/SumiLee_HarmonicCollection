const audio = document.getElementById('audio');
const lyricsContainer = document.getElementById('lyrics');
const lyricsData = [
  { time: 13, text: 'Invading all my weakness You wrapped me up in grace' },
  { time: 19, text: 'The worst of me succeeded by the best of You' },
  { time: 40, text: 'My heart is overtaken My soul is overwhelmed' },
  { time: 47, text: 'The worst of me succeeded by the best of You' },
  { time: 53, text: 'My dreams have found their purpose My future in Your hands' },
  { time: 61, text: 'This life would have no meaning If it werent for You' },
  { time: 67, text: 'So I lay me down For kingdom come' },
  { time: 75, text: 'Steal all that is within me Cause all I want in this world Is more of You' },
  { time: 83, text: 'In the less of me it is You Increasing as I fade away Your light for all the world to see' },
  { time: 95, text: 'God it is You who breaks the chains It is You who lights the way And everything I am cries out for You' },
  { time: 108, text: 'Lord make my life transparent Your life in mine displayed' },
  { time: 116, text: 'Let every earthly glory go back to You' },
  { time: 123, text: 'So I lay me down For kingdom come' },
  { time: 130, text: 'Steal all that is within me Cause all I want in this world Is more of You' },
  { time: 138, text: 'In the less of me it is You Increasing as I fade away Your light for all the world to see' },
  { time: 149, text: 'God it is You who breaks the chains It is You who lights the way And everything I am cries out for You' },
  { time: 164, text: 'Woah' },
  { time: 177, text: 'So I lay me down' },
  { time: 191, text: 'So I lay me down For kingdom come' },
  { time: 198, text: 'Steal all that is within me Cause all I want in this world Is more of You' },
  { time: 206, text: 'In the less of me it is You Increasing as I fade away Your light for all the world to see' },
  { time: 218, text: 'God it is You who breaks the chains It is You who lights the way And everything I am cries out for You' },
  { time: 233, text: 'Woah' },
];

audio.addEventListener('timeupdate', () => {
  const currentTime = Math.floor(audio.currentTime);
  const currentLyrics = lyricsData.find(lyric => lyric.time <= currentTime && lyric.time + 5 > currentTime);

  if (currentLyrics) {
    highlightLyrics(currentLyrics);
  }
});

function highlightLyrics(lyrics) {
  const formattedLyrics = lyrics.text
    .split('\n')
    .map(line => `<p>${line}</p>`)
    .join('');

  lyricsContainer.innerHTML = formattedLyrics;
}
