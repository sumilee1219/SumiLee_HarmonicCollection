document.addEventListener("DOMContentLoaded", function () {
    const lyricsContainer = document.getElementById("karaoke-lyrics");
    const lines = lyricsContainer.querySelectorAll("p");
    const audio = document.getElementById("audio");
    let currentIndex = 0;


    function updateActiveLine() {
        const currentTime = audio.currentTime;


        for (let i = 0; i < lines.length; i++) {
            const startTime = parseFloat(lines[i].getAttribute("data-start-time"));
            if (startTime <= currentTime && (i === lines.length - 1 || currentTime < parseFloat(lines[i + 1].getAttribute("data-start-time"))) ) {
                currentIndex = i;
                break;
            }
        }

        for (let i = 0; i < lines.length; i++) {
            if (i === currentIndex) {
                lines[i].classList.add("active");
            } else {
                lines[i].classList.remove("active");
            }
        }
    }

    audio.addEventListener("timeupdate", updateActiveLine);
});

const audio = document.getElementById("audio"); 
const playButton = document.getElementById("play-button"); 
const progressBar = document.getElementById("progress-bar"); 

playButton.addEventListener("click", function () {
    if (audio.paused) {
        audio.play();
    } else {
        audio.pause();
    }
});

audio.addEventListener("timeupdate", function () {
    const currentTime = audio.currentTime;
    const duration = audio.duration;
    const progress = (currentTime / duration) * 100;
    progressBar.style.width = `${progress}%`;
});

const customCursor = document.getElementById("custom-cursor");

document.addEventListener("mousemove", (e) => {
    customCursor.style.left = e.clientX + "px";
    customCursor.style.top = e.clientY + "px";
});
